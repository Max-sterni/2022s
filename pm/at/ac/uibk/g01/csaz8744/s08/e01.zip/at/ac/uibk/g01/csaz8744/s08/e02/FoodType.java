package at.ac.uibk.pm.g01.csaz8744.s08.e02;

public enum FoodType {
    FRUIT, VEGGIE, MEAT, DAIRY, SWEETS, MUNCHIES
}
