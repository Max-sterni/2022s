package at.ac.uibk.pm.g01.csaz8744.s07.e01;

public interface Identifiable<UniqueIdentifier> {

    UniqueIdentifier getUniqueIdentifier();

}
