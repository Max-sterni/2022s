package at.ac.uibk.pm.g01.csaz8744.midterm1.e01;

public enum Position {
    LEFT,
    CENTER,
    RIGHT
}


