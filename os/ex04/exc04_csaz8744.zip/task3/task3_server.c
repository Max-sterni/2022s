#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <poll.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

int simple_hash(char *key, int len);

unsigned int main(unsigned int argc, char *argv[])
{
    // Guard
    if (argc < 2)
    {
        fprintf(stderr, "invalid input\n");
        return EXIT_FAILURE;
    }
    
    //Create Path
    char * path_template = "/tmp/task3-fifo-";
    char * path = malloc(_PC_PATH_MAX);
    memset(path, 0, _PC_PATH_MAX);

    // Create the pipes
    unsigned int hash_list[argc - 1];
    for (int i = 1; i < argc; i++)
    {
         
        //Name the fifo
        hash_list[i - 1] = simple_hash(argv[i], strlen(argv[i]));
        sprintf(path, "%s%u", path_template, hash_list[i - 1]);

        //Create the fifo
        if(mkfifo(path, 0770) != 0){
            fprintf(stderr, "Fifo error\n");
            return EXIT_FAILURE;
        }
        int pipe_fd = open(path, 'r');
        char buffer[4096];

        //Pollin
        struct pollfd poll_fd;
        poll_fd.fd = pipe_fd;
        poll_fd.events = POLLIN;
        poll(&poll_fd, 1, -1);

        read(pipe_fd, buffer, 4096);
        write(STDOUT_FILENO, buffer, strlen(buffer));
        remove(path);
    }   
    //Cleanup
    free(path);

    return EXIT_SUCCESS;
}

int simple_hash(char *key, int len)
{
    int hash, i;
    for (hash = i = 0; i < len; ++i)
    {
        hash += key[i];
        hash += (hash << 10);
        hash ^= (hash >> 6);
    }
    hash += (hash << 3);
    hash ^= (hash >> 11);
    hash += (hash << 15);
    return hash;
}