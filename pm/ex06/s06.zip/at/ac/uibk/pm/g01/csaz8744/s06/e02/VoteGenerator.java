package at.ac.uibk.pm.g01.csaz8744.s06.e02;

import java.util.Set;

public interface VoteGenerator {

    public void distributeVotes(Set<PoliticalParty> parties, Set<ElectoralRegion> regions);

}
