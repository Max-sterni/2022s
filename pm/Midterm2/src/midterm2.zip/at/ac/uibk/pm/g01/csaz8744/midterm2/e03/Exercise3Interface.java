package at.ac.uibk.pm.g01.csaz8744.midterm2.e03;

import java.util.List;
import java.util.Optional;

public interface Exercise3Interface {

    List<Integer> methodA(final List<Integer> list);

    int methodB(final List<List<Integer>> lists);

    Optional<String> methodC(final List<String> list);
}
