package at.ac.uibk.pm.g01.csaz8744.s03.e05;

/**
 * Color
 */
public enum Color {
    RED,
    GREEN,
    BLUE;
}