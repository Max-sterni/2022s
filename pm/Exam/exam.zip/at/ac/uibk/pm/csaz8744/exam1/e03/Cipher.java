package at.ac.uibk.pm.csaz8744.exam1.e03;

public abstract class Cipher {
    abstract String encipher(String message);
    abstract String decipher(String message);
}
