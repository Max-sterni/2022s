int iterate(int n){
	return ++n;
}
