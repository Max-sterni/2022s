package at.ac.uibk.pm.g01.csaz8744.midterm1.e01;

public class OutfieldPlayer {
    private String name;
    private Position position;

    public OutfieldPlayer(String name, Position position) {
        this.name = name;
        this.position = position;
    }

    private String positionToString(){
        switch (position){
            case LEFT -> {
                return "left";
            }
            case RIGHT -> {
                return "right";
            }
            case CENTER -> {
                return "center";
            }
            default -> {
                return "";
            }
        }
    }

    @Override
    public String toString() {
        return name + " in " + positionToString() + " position";
    }
}
