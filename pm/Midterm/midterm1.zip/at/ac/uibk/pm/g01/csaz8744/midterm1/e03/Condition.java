package at.ac.uibk.pm.g01.csaz8744.midterm1.e03;

public enum Condition {
    NEW,
    GOOD_AS_NEW,
    OBVIOUS_SIGNS_OF_WEAR
}
