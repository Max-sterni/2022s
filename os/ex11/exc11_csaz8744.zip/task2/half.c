int half(int n){
	return n / 2;
}
