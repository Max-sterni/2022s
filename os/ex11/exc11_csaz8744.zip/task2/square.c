#include <stdlib.h>

int square(int n){
	return n * n;
}
